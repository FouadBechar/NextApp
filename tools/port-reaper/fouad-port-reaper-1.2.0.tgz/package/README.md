# `fouad-port-reaper`

Windows CLI to find and kill the process listening on a specific port.

## Package and command

- npm package: `fouad-port-reaper`
- CLI command: `port-reaper`

## Install from npm

```bash
npm install -g fouad-port-reaper
port-reaper --help
```

## Usage

```bash
port-reaper 3000
port-reaper 3000 --dry-run
port-reaper --kill 3000
port-reaper --list
port-reaper --version
```

## Notes

- Windows only
- The tool only targets processes in the `LISTENING` state
- `--kill` runs a quicker output mode for direct termination
- `--list` shows all listening ports before you choose one to kill
- `--dry-run` shows what would be killed without actually killing it
- Protected PIDs such as `0` and `4` are blocked from termination
- Ports are strictly validated as numeric values between `1` and `65535`

## Example output

```text
Port Reaper

-> Port: 3000
-> Process: node.exe (PID: 12345)
-> Address: 0.0.0.0:3000
-> Protocol: TCP

Terminated successfully
```
