import { execFile } from "child_process";

export function parsePid(value) {
  const normalized = String(value || "").trim();

  if (!/^\d+$/.test(normalized)) {
    throw new Error("PID must be a numeric value.");
  }

  return normalized;
}

export function killPort(pidInput) {
  const pid = parsePid(pidInput);

  return new Promise((resolve, reject) => {
    execFile("taskkill", ["/F", "/PID", pid], { windowsHide: true }, (error, stdout, stderr) => {
      if (error) {
        reject(new Error(stderr || error.message));
        return;
      }

      resolve(stdout);
    });
  });
}
