#!/usr/bin/env node

import chalk from "chalk";
import { createRequire } from "module";
import { scanPort, parsePort, listPorts } from "../core/scan-ports.mjs";
import { killPort } from "../core/kill-port.mjs";

const require = createRequire(import.meta.url);
const { version } = require("../package.json");
const args = process.argv.slice(2);

if (args.includes("--help") || args.includes("-h")) {
  console.log(chalk.bold("port-reaper"));
  console.log("Find and kill the process listening on a specific port (Windows).\n");
  console.log(chalk.gray("Usage:"));
  console.log("  port-reaper 3000");
  console.log("  port-reaper 3000 --dry-run");
  console.log("  port-reaper --list");
  console.log("  port-reaper --version");
  process.exit(0);
}

if (args.includes("--version") || args.includes("-v")) {
  console.log(version);
  process.exit(0);
}

const portArg = args.find((arg) => !arg.startsWith("-"));
const dryRun = args.includes("--dry-run");
const listOnly = args.includes("--list");

if (listOnly) {
  try {
    const ports = await listPorts();

    if (ports.length === 0) {
      console.log(chalk.yellow("No listening ports found."));
      process.exit(0);
    }

    console.log(chalk.cyan("Listening Ports\n"));
    for (const entry of ports) {
      console.log(`- port: ${entry.port} | pid: ${entry.pid} | protocol: ${entry.protocol} | address: ${entry.localAddress}`);
    }
    process.exit(0);
  } catch (error) {
    console.error(chalk.red(`Failed: ${error.message}`));
    process.exit(1);
  }
}

if (!portArg) {
  console.error(chalk.red("Please provide a port."));
  console.log(chalk.gray("Usage:"));
  console.log(chalk.cyan("  port-reaper 3000"));
  process.exit(1);
}

let port;

try {
  port = parsePort(portArg);
} catch (error) {
  console.error(chalk.red(error.message));
  process.exit(1);
}

try {
  const result = await scanPort(port);

  if (!result) {
    console.log(chalk.yellow(`No listening process found on port ${port}.`));
    process.exit(0);
  }

  console.log(chalk.cyan("Port Reaper Report\n"));
  console.log(`- port: ${result.port}`);
  console.log(`- pid: ${result.pid}`);
  console.log(`- protocol: ${result.protocol}`);
  console.log(`- local address: ${result.localAddress}`);

  if (dryRun) {
    console.log(chalk.green("\nDry run only. No process was killed."));
    process.exit(0);
  }

  await killPort(result.pid);
  console.log(chalk.green(`\nKilled process ${result.pid} on port ${result.port}.`));
} catch (error) {
  console.error(chalk.red(`Failed: ${error.message}`));
  process.exit(1);
}
